
## How to check if the task is completed ?

bundle install

rspec library_manager_spec.rb